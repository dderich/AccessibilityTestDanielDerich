// JavaScript Document
const navigationToggleButton = document.getElementById('nav-toggle');
const nav = document.getElementById('main-nav');

const firstNavLink = nav.querySelector('a'); // moves cursor to first link in navigation list

navigationToggleButton.addEventListener('click', () => {
    const isExpanded = navigationToggleButton.getAttribute('aria-expanded') === 'true';

    navigationToggleButton.setAttribute('aria-expanded', !isExpanded);

    nav.style.display = isExpanded ? 'none' : 'block';

    navigationToggleButton.textContent = isExpanded ? 'Show Navigation Links' : 'Hide Navigation Links';


    if (!isExpanded) {
        firstNavLink.focus();
    } else {
        navigationToggleButton.focus();
    }
});